export const $ = document.querySelector.bind(document)
export const $$ = document.querySelectorAll.bind(document)
