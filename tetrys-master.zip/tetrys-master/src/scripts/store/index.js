import configureStore from './configureStore'

export default configureStore
export * from './connect'
