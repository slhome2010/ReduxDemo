export const SPACE_BAR = 32
export const UP_ARROW = 38
export const LEFT_ARROW = 37
export const RIGHT_ARROW = 39
export const DOWN_ARROW = 40
