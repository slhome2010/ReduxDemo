export const BOARD_FREEZE = 'BOARD_FREEZE'
export const BOARD_LINE_REMOVE = 'BOARD_LINE_REMOVE'
export const BOARD_COLUMNS = 10
export const BOARD_ROWS = 20
