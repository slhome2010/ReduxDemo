export const GAME_START = 'GAME_START'
export const GAME_PAUSED = 'GAME_PAUSED'
export const GAME_END = 'GAME_END'
export const GAME_LEVEL_UPDATE = 'GAME_LEVEL_UPDATE'
